package main.java.util;

import main.java.user.User;

public interface UserInterface {
    void setUser(User user);
}
